package com.smartmarmot.dbforbix.config.item;

import java.util.Set;

import org.apache.commons.lang3.NotImplementedException;

import com.smartmarmot.dbforbix.config.element.IConfigurationElement;

public class ConfigurationItemParserNative implements IConfigurationItemParser {

	public ConfigurationItemParserNative(String config) {
		// TODO Auto-generated constructor stub
		throw new NotImplementedException("ConfigurationItemParserNative class is not implemented yet!");
	}

	@Override
	public Set<IConfigurationElement> buildConfigurationElements() {
		// TODO Auto-generated method stub
		return null;
	}

}
