package com.smartmarmot.dbforbix.config.item;

public enum ConfigurationItemType {
 XML, Native;
}
